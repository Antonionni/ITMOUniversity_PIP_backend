CREATE FUNCTION check_id()
  RETURNS trigger
LANGUAGE plpgsql
AS $$
DECLARE
    foundId INTEGER;
BEGIN
  EXECUTE 'SELECT id from ' || TG_TABLE_NAME || ' where id = ' || NEW.id || ''  INTO foundId;
	IF (foundId <> NULL) THEN
		RAISE EXCEPTION 'Пользователь с таким ID уже существует';
	END IF;
RETURN NEW;
END
$$;

